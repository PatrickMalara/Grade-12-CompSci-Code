﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sam_s_Necklace
{
    class Program
    {
        static void Main(string[] args)
        {
            int firstNum = 0, secondNum = 0, sum = 0, sumGive = 0,
                sumCheck = 0, outOne = 0, outTwo = 0, print = 0;

            Console.Write("Enter the first number: ");
            firstNum = int.Parse(Console.ReadLine());
            Console.Write("Enter the second number: ");
            secondNum = int.Parse(Console.ReadLine());

            sumCheck = firstNum + secondNum;
            sum = secondNum + sumCheck;
            sumGive = sum - (sum / 10) * 10;
            outOne = sumCheck;
            outTwo = sumGive;
            sum = sumGive + sumCheck;
            sumCheck = sumGive;
            sumGive = sum - (sum / 10) * 10;

            while(outOne != firstNum && outTwo != secondNum)
            Console.WriteLine(print)
            Console.ReadLine();
        }
    }
}
