/*
    Author: Patrick Malara
    Date: April 28, 2016
    Program: Unit 8 Assignment
*/

#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cstdio>
#include <string>
#include <math.h>

struct Node{
    char graphic;
    int x;  ///X axis
    int y;  ///Y axis

    int g;  ///G Cost
    int h;  ///H Cost
    double f;  ///F Cost

    bool checked;
    bool used;
    bool full;
    Node* next;

    Node& connectedNodes[4];
};

class LinkedList{

private:

    Node* head;
    Node* temp;

public:

    LinkedList(){



        head=NULL;
        temp=NULL;
    }

    ~LinkedList(){
        if  ( head != NULL){

            Node* toDelete = head;
            Node* next = NULL;

            do{
                next = toDelete->next;
                delete toDelete;
                toDelete = next;
            }while ( toDelete != NULL);

        }

    }


    Node* getHead(){ return head; }

    void addNode(char graphic, int x, int y, bool full){

        Node* n = new Node();
        n->graphic = graphic;
        n->x = x;
        n->y = y;
        n->full = full;
        n->next = NULL;
        for(int i = 0; i < 4; i++)  n->connectedNodes[i] = NULL;

        if(head == NULL)    //If there is no List made
            head = n;   // set the head to the new Node created
        else if(head != NULL){  //If there is a List already made
            temp = head;
            while(temp->next != NULL)   //Get to the end of the list to add the new Node created
                temp = temp->next;
            temp->next = n;     // Add the new Node to the List
        }

    }

    void addNode(Node* toAdd){

        if(head == NULL)
            head = toAdd;
        else{
            temp = head;
            while(temp->next != NULL)   //Get to the end of the list to add the new Node created
                temp = temp->next;
            temp->next = toAdd;     // Add the new Node to the List
        }

    }

};

int main()
{
    std::string fileName = "map.txt";    ///Map File
    Node* curr = new Node();

    std::ifstream in("map.txt", std::ios::in | std::ios::binary);
    if(!in){
        std::cerr << "Cannot open file" << std::endl;
        return 1;
    }


    //ifstream infile("map.txt", ios::in);

    ///Set the array size
    std::string tempY;
    std::getline(in, tempY);
    int yAmt = atoi( tempY.c_str() ); ///std::stoi(tempY);

    std::string tempX;
    std::getline(in, tempX);
    int xAmt = atoi( tempX.c_str() ); ///std::stoi(tempY);

    char nodesArray[xAmt][yAmt];

    LinkedList myList;  ///List for the nodes
    int xAxisCounter = -1;
    int yAxisCounter = 0;

    //std::cout << xAmt << ", " << yAmt << std::endl;


    std::string line;
    //while(in){
    for(int l = 0; l < yAmt; l++){
        std::getline(in, line);

        std::cout << line << std::endl;
        for(int i = 0; i < xAmt; i++){
            if(line[i] == 'X')
                myList.addNode('X', i, l, true);
            else if(line[i] == ' ')
                myList.addNode(' ', i, l, false);
            else if(line[i] == '$')
                myList.addNode('$', i, l, false);
        }

    }

    ///MESSI, MESSI, MESSI, GOAL, GOAL, GOAL!
    Node* goalNode = new Node();
    curr = myList.getHead();
    while(curr != NULL)
    {
        if(curr->graphic == '$')
            goalNode = curr;

        curr = curr->next;

    }

    ///Setting Up All of the connectedNodes for all of the Nodes
    curr = myList.getHead();    ///Reset Curr
    Node* cachePointer = new Node();
    cachePointer = myList.getHead();
    while(curr != NULL){    ///Order of ConnectedNodes : Up, Down, Left, and Right
        ///Up node
        while(cachePointer != NULL){
            if(cachePointer->x == curr->x && cachePointer->y == curr->y + 1)   ///Up Connected Node
                curr->connectedNodes[0] = cachePointer;
            else if(cachePointer->x == curr->x && cachePointer->y == curr->y - 1)   ///Down Connected Node
                curr->connectedNodes[1] = cachePointer;
            else if(cachePointer->y == curr->y && cachePointer->x == curr->x - 1)   ///Left Connected Node
                curr->connectedNodes[2] = cachePointer;
            else if(cachePointer->y == curr->y && cachePointer->x == curr->x + 1)   ///Right Connected Node
                curr->connectedNodes[3] = cachePointer;

            cachePointer = cachePointer->next;
        }
        ///Filling in the distance, or fCost
        curr->f = sqrt(pow(goalNode->x - curr->x, 2) + pow(goalNode->y - curr->y, 2));

        curr = curr->next;
    }

    Node* movingNode = new Node();
    curr = myList.getHead();    ///Reset Curr
    while(curr != NULL){
        if(curr->x == 1 && curr->y == 1)
            movingNode = curr;
        curr = curr->next;
    }

    ///Now our moving node is filled, noice
    LinkedList pathList;
    pathList.addNode(movingNode);   ///Starting out stack of nodes to use

    ///LOOP TO FIND GOAL - FIRST NEED TO FILL IN THE DISTANCE FOR NODES
    curr = myList.getHead();
    Node* cachePointer2 = new Node();
    while(movingNode->x != goalNode->x && movingNode->y != goalNode->y)
    {
        std::cout << movingNode->x << ", " << movingNode->y << std::endl;

        cachePointer2->f = movingNode->f;
        for(int i = 0; i < 4; i++)
        {
            if(movingNode->connectedNodes[i]->f <= cachePointer2->f
               && movingNode->connectedNodes[i] != NULL
               && !movingNode->connectedNodes[i]->full)
                cachePointer2 = movingNode->connectedNodes[i];

        }
        ///Now we should have a gOoOoOooOoOoOoOOD Time with our node that we need to moveTo
        movingNode = cachePointer2;

    }

    std::cout << "("<< goalNode->x << " " << goalNode->y << ") = " << goalNode->full << std::endl;
    //std::cout << "Nodes" << std::endl;


    curr = myList.getHead();

    while(curr != NULL)
    {
        std::cout << "("<< curr->x << " " << curr->y << ") = " << curr->full << std::endl;
        curr = curr->next;
    }

    //test
    myList.addNode(movingNode);


    delete curr;

    in.close();
    //in.close(); ///Close the file

    return 0;
}
