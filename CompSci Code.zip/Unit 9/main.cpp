#include <iostream>
#include <string>

using namespace std;

struct Item{

    string data;
    int amountOfThis;

    Item* next;

};

class LinkedList{

private:

    Item* head;
    Item* temp;

public:

    LinkedList(){
        head=NULL;
        temp=NULL;
    }

    ~LinkedList(){
        if  ( head != NULL){

            Item* toDelete = head;
            Item* next = NULL;

            do{
                next = toDelete->next;
                delete toDelete;
                toDelete = next;
            }while ( toDelete != NULL);

        }

    }

    Item* getHead(){ return head; }

    void addItem(string data){

        Item* n = new Item();
        n->data = data;
        n->amountOfThis = 1;
        n->next = NULL;

        if(head == NULL)    //If there is no List made
            head = n;   // set the head to the new Item created
        else if(head != NULL){  //If there is a List already made
            temp = head;
            while(temp->next != NULL)   //Get to the end of the list to add the new Item created
                temp = temp->next;
            temp->next = n;     // Add the new Item to the List
        }

    }

};

int main()
{
    string input = "/0";
    Item* temp = new Item();
    LinkedList myList;

    while(input != "END"){

        cin>>input;
        if(input == "END")
            break;

        if(myList.getHead() == NULL)
            myList.addItem(input);
        else{

            temp = myList.getHead();

            bool increment = false;

            while(temp != NULL && !increment)
            {
                if(temp->data == input){
                    temp->amountOfThis += 1;
                    increment = true;
                }
                temp = temp->next;
            }

            if(!increment)
                myList.addItem(input);
        }
    }

    Item* curr = new Item();
    curr = myList.getHead();

   cout << "You Entered: " << endl;

    while(curr != NULL)
    {
        cout << curr->amountOfThis << " " << curr->data<<endl;
        curr = curr->next;
    }

    return 0;
}
