/*
    Author: Patrick Malara
    Date: June 18, 2016
    Program: Execution of various algorithms
*/

#include <ctime>
#include <iostream>
#include <fstream>
#include <time.h>


using namespace std;

void bubbleSort(int a[], int amount)
{
    for (int k = 1; k < amount; k++)
      for (int i = 0; i < amount - 1 - k; i++)
        if (a[i] > a[i + 1]){
            int temp = a[i];
            a[i] = a[i + 1];
            a[i + 1] = temp;
        }
}

void selectionSort(int a[], int amount)
{
    for (int i = 0; i < amount - 1; ++i) {
        int iSmallest = i;
        for (int j = i + 1; j < amount; ++j) {
            if (a[iSmallest] > a[j]) {
                iSmallest = j;
            }
        }

        int iSwap     = a[iSmallest];
        a[iSmallest]  = a[i];
        a[i]          = iSwap;
    }
}

int Partition(int a[], int beg, int e)
{
    int p = beg, pivot = a[beg], loc;

    for(loc = beg + 1; loc <= e; loc++)
    {
        if(pivot>a[loc])
        {
            a[p] = a[loc];
            a[loc] = a[p+1];
            a[p+1] = pivot;

            p = p++;
        }
    }
    return p;
}


void QuickSort(int a[], int beg, int e)
{
    if(beg < e)
    {
        int p = Partition(a, beg, e);

        QuickSort(a, beg, p-1);
        QuickSort(a, p+1, e);
    }
}

void Merge(int* ipA, int iEnd1, int iEnd2) {
    int i = 0;
    int j = iEnd1;
    int k = 0;
    int* ipTemp = new int[iEnd2];
    // Take each next smallest element
    while (i < iEnd1 && j < iEnd2) {
        if (ipA[i] < ipA[j]) {
            ipTemp[k] = ipA[i];
            ++i;

        } else {
            ipTemp[k] = ipA[j];
            ++j;
        }
        ++k;
    }
    // Copy any remaining elements of the 1st numsay
    while (i < iEnd1) {
        ipTemp[k] = ipA[i];
        ++i;
        ++k;
    }
    // Copy any remaining elements of the 2nd numsay
    while (j < iEnd2) {
        ipTemp[k] = ipA[j];
        ++j;
        ++k;
    }
    // Copy the merged array back to the original
    for (int iIndex = 0; iIndex < iEnd2; ++iIndex) {
        ipA[iIndex] = ipTemp[iIndex];

    }
    delete [] ipTemp;
}

void MergeSort(int nums[], int aSize)
{
    for (int i = 1; i < aSize; i *= 2) {
        for (int j = 0; j < aSize - i; j += 2*i) {
            int iEnd2 = (2*i < aSize - j) ? 2*i : aSize - j;
            Merge(&(nums[j]), i, iEnd2);
        }
    }
}

void insertion_sort (int arr[], int amount){
    int j, temp;

	for (int i = 0; i < amount; i++){
		j = i;

		while (j > 0 && arr[j] < arr[j-1]){
			  temp = arr[j];
			  arr[j] = arr[j-1];
			  arr[j-1] = temp;
			  j--;
        }
    }
}

int main(){

    ///Variables
    string fileName = "numbers.txt";
    int input;
    double t1, t2;

    ///Open the file
    ifstream infile;
    infile.open(fileName.c_str());

    ///Error Checking
    if(!infile.is_open())
    {
        ///Le problemo hereo
        cerr << "Unable to open file: " << fileName << endl;
        return 1;
    }

    int amount = 10000;
    int nums[amount];

    for(int i = 0; i < amount; i++)
        infile >> nums[i];

    while(input != 0){
        cout << "\n\n1 - Sort Using 100 Numbers" << endl;
        cout << "2 - Sort Using 1000 Numbers" << endl;
        cout << "3 - Sort Using 10000 Numbers" << endl;
        cout << "\n0 - Exit" << endl;
        cin >> input;
        if(input == 1){
            amount = 100;
            ///Read the file and insert the numbers in the array
            for(int i = 0; i < amount; i++)
                infile >> nums[i];  ///Now I have the array
            ///Time to sort, and time
            t1 = clock();
            bubbleSort(nums, amount);
            t2 = clock();
            cout << "\nBubbleSort Time: " << (t2 - t1)/CLK_TCK;

            ///Read the file and insert the numbers in the array
            for(int i = 0; i < amount; i++)
                infile >> nums[i];  ///Now I have the array
            ///Time to sort, and time
            t1 = clock();
            MergeSort(nums, amount);
            t2 = clock();
            cout << "\nMergeSort Time: " << (t2 - t1)/CLK_TCK;

            ///Read the file and insert the numbers in the array
            for(int i = 0; i < amount; i++)
                infile >> nums[i];  ///Now I have the array
            ///Time to sort, and time
            t1 = clock();
            QuickSort(nums, 0, amount);
            t2 = clock();
            cout << "\nQuickSort Time: " << (t2 - t1)/CLK_TCK;

            ///Read the file and insert the numbers in the array
            for(int i = 0; i < amount; i++)
                infile >> nums[i];  ///Now I have the array
            ///Time to sort, and time
            t1 = clock();
            selectionSort(nums, amount);
            t2 = clock();
            cout << "\nSelectionSort Time: " << (t2 - t1)/CLK_TCK;

            ///Read the file and insert the numbers in the array
            for(int i = 0; i < amount; i++)
                infile >> nums[i];  ///Now I have the array
            ///Time to sort, and time
            t1 = clock();
            insertion_sort(nums, amount);
            t2 = clock();
            cout << "\nInsertionSort Time: " << (t2 - t1)/CLK_TCK;
        }
        else if(input == 2){
            amount = 1000;
            ///Read the file and insert the numbers in the array
            for(int i = 0; i < amount; i++)
                infile >> nums[i];  ///Now I have the array
            ///Time to sort, and time
            t1 = clock();
            bubbleSort(nums, amount);
            t2 = clock();
            cout << "\nBubbleSort Time: " << (t2 - t1)/CLK_TCK;

            ///Read the file and insert the numbers in the array
            for(int i = 0; i < amount; i++)
                infile >> nums[i];  ///Now I have the array
            ///Time to sort, and time
            t1 = clock();
            MergeSort(nums, amount);
            t2 = clock();
            cout << "\nMergeSort Time: " << (t2 - t1)/CLK_TCK;

            ///Read the file and insert the numbers in the array
            for(int i = 0; i < amount; i++)
                infile >> nums[i];  ///Now I have the array
            ///Time to sort, and time
            t1 = clock();
            QuickSort(nums, 0, amount);
            t2 = clock();
            cout << "\nQuickSort Time: " << (t2 - t1)/CLK_TCK;

            ///Read the file and insert the numbers in the array
            for(int i = 0; i < amount; i++)
                infile >> nums[i];  ///Now I have the array
            ///Time to sort, and time
            t1 = clock();
            selectionSort(nums, amount);
            t2 = clock();
            cout << "\nSelectionSort Time: " << (t2 - t1)/CLK_TCK;

            ///Read the file and insert the numbers in the array
            for(int i = 0; i < amount; i++)
                infile >> nums[i];  ///Now I have the array
            ///Time to sort, and time
            t1 = clock();
            insertion_sort(nums, amount);
            t2 = clock();
            cout << "\nInsertionSort Time: " << (t2 - t1)/CLK_TCK;
        }
        else if(input == 3){
            amount = 10000;
            ///Read the file and insert the numbers in the array
            for(int i = 0; i < amount; i++)
                infile >> nums[i];  ///Now I have the array
            ///Time to sort, and time
            t1 = clock();
            bubbleSort(nums, amount);
            t2 = clock();
            cout << "\nBubbleSort Time: " << (t2 - t1)/CLK_TCK;

            ///Read the file and insert the numbers in the array
            for(int i = 0; i < amount; i++)
                infile >> nums[i];  ///Now I have the array
            ///Time to sort, and time
            t1 = clock();
            MergeSort(nums, amount);
            t2 = clock();
            cout << "\nMergeSort Time: " << (t2 - t1)/CLK_TCK;

            ///Read the file and insert the numbers in the array
            for(int i = 0; i < amount; i++)
                infile >> nums[i];  ///Now I have the array
            ///Time to sort, and time
            t1 = clock();
            QuickSort(nums, 0, amount);
            t2 = clock();
            cout << "\nQuickSort Time: " << (t2 - t1)/CLK_TCK;

            ///Read the file and insert the numbers in the array
            for(int i = 0; i < amount; i++)
                infile >> nums[i];  ///Now I have the array
            ///Time to sort, and time
            t1 = clock();
            selectionSort(nums, amount);
            t2 = clock();
            cout << "\nSelectionSort Time: " << (t2 - t1)/CLK_TCK;

            ///Read the file and insert the numbers in the array
            for(int i = 0; i < amount; i++)
                infile >> nums[i];  ///Now I have the array
            ///Time to sort, and time
            t1 = clock();
            insertion_sort(nums, amount);
            t2 = clock();
            cout << "\nInsertionSort Time: " << (t2 - t1)/CLK_TCK;
        }
    }

    infile.close();

    return 0;
}
