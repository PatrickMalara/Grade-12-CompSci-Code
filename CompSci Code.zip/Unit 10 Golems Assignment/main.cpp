/*
Author: Patrick Malara
Date: June 22, 2016
Program: Unit 10 - Golems Remastered
*/
#include <iostream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main()
{
    ///Generate a random secret code for the City Watch to find
    char secretCode[5];
    srand(time(NULL)); ///Random seed
    for(int i = 0; i < 4; i++)
    {
        int temp = rand() % 4 + 1;  /// random number from 1 - 4
        ///If temp is equal to a certain number than assign a certain element
        if(temp == 1)
            secretCode[i] = 'E';
        else if( temp == 2)
            secretCode[i] = 'A';
        else if( temp ==  3)
            secretCode[i] = 'W';
        else if( temp ==  4)
            secretCode[i] = 'F';
    }
    secretCode[4] = '\0';

    ///Variables for the player, the input string, and the amount of attempts
    char input[5];
    int attempts = 0;

    std::cout << "Secret (for testing) = "<< secretCode << std::endl;

    ///Output the rules of the game
    std::cout << "\n\tThe golems of the City of Ankh Morpork are rising up! \nYou are apart of the city's police force, the City Watch, your duty is to stop them!\n" <<
                 "The golems are controlled by small spells that are put inside their heads.\nYou need to find the correct combination so they retrun to their docile state.\n" <<
                 "They are made up of a sequence of 4 elements selected from the following: Fire, Water, Air, and Earth.\n" <<
                 "\n\tFortunately, the golems have eyes that will glow in a way that will give the Watch some clues. \nTheir eyes will glow RED for each element that is in the correct location.\n" <<
                 "Their eyes will glow BLUE for each element that is correctly included, but in the wrong location.\n";

    ///Here is the game loop
    do{
        attempts++; ///incrementing the attempts
        std::cout << "\n\nEnter code (Attempt " << attempts << "): ";

        gets(input);    ///read the inputed string

        ///Capitalize the characters in the input string
        int tempInt = 0;
        char tempChar;
        while (input[tempInt])
        {
            tempChar = input[tempInt];
            input[tempInt] = (toupper(tempChar));
            tempInt++;
        }

        std::cout << " Result:";
        int blues   = 0;    ///The amount of blues in the input
        int reds    = 0;    ///The amount of reds in the input
        ///The following are the variables for the elements
        ///they will be used for calculating the amount of blues
        int waters  = 0;
        int fires   = 0;
        int earths  = 0;
        int airs    = 0;

        for(int i = 0; i < 4; i++){
            if(input[i] != secretCode[i]){
                ///Check if input[i] is equal to any other chars in the secretcode
                for(int j = 0; j < 4; j++){
                    if(input[i] == secretCode[j]){
                        ///Check if that secretCode char is equal to the one below it
                        if(input[j] != secretCode[j]){
                            if(secretCode[j] == 'W')
                                waters++;
                            else if(secretCode[j] == 'F')
                                fires++;
                            else if(secretCode[j] == 'E')
                                earths++;
                            else if(secretCode[j] == 'A')
                                airs++;
                            break;
                        }
                    }
                }

                ///Here I kinda 'normalize' all the elements from the input... i dont really know what to call it
                if(waters > 1)
                    waters = 1;
                if(fires > 1)
                    fires = 1;
                if(earths > 1)
                    earths = 1;
                if(airs > 1)
                    airs = 1;
            }
            else    ///If the elements match
                reds++;

            blues = waters + fires + earths + airs;    ///Add all the elements to get the blues
        }

        ///Loop through all of the reds and blues for the output/ Golem's Eyes
        for(int r = 0; r < reds; r++)
            std::cout << "R";
        for(int b = 0; b < blues; b++)
            std::cout << "B";

    } while(attempts != 10 && strcmp(input, secretCode));

    ///End Game Output
    if(attempts == 10)
        std::cout << "\n\nToo late!!!!" << std::endl;
    else if(strcmp(input, secretCode) == false)
        std::cout << "\n\nPhew... another job well done by the City Watch" << std::endl;

    return 0;
}
