#include <iostream>

using namespace std;

int fib(int first, int second){
    int answer;
    if(second == 1) return 1;
    answer = factr(first + 1, second - 1);
    return(answer);
}

int main()
{
    cout << "4 factorial is: " << fib(5, 3);
    return 0;
}
