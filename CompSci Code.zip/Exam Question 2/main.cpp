/*
    Author: Patrick Malara
    Program: Question 2
*/

#include <iostream>
#include <fstream>
#include <string.h>

using namespace std;

int CountTotalMoney(char mapArray[5][8]){

    int dollhairCounter = 0;

    for (int y = 0; y < 5; y++){
        for (int x = 0; x < 8; x++)
        if(mapArray[y][x] == '$'){
            dollhairCounter++;
        }
    }

    return dollhairCounter;
}

int main()
{
    ///Variables
    string fileName = "test.txt";

    ///Opening the text file
    ifstream infile;
    infile.open(fileName.c_str());

    ///Check for Errors
    if(!infile.is_open())
    {
        cerr << "Cant open the text file: " << fileName << endl;
        return 1;
    }

    ///Now we have to loop through the lines and gathers them into an two dimensinal array
    char economy[5][8];

    for (int y = 0; y < 5; y++){
        for (int x = 0; x < 8; x++)
        infile >> economy[y][x];
    }

    for (int y = 0; y < 5; y++){
        for (int x = 0; x < 8; x++)
        cout << economy[y][x];
    }

    cout << "\n\n Amount of Dollars: " << CountTotalMoney(economy);

    infile.close(); ///Close the file

    return 0;
}
