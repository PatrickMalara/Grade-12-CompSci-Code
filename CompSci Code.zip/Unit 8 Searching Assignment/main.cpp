/*
    Author: Patrick Malara
    Date: April 28, 2016
    Program: Unit 8 Assignment
*/

#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cstdio>
#include <string>
#include <math.h>

struct Node{
    char graphic;
    int x;  ///X axis
    int y;  ///Y axis

    double f;  ///F Cost

    bool checked;
    bool used;
    bool full;

    //Node connectedNodes[4];
};

int main()
{
    std::string fileName = "map.txt";    ///Map File
    Node* curr = new Node();

    std::ifstream in("map.txt", std::ios::in | std::ios::binary);
    if(!in){
        std::cerr << "Cannot open file" << std::endl;
        return 1;
    }


    //ifstream infile("map.txt", ios::in);

    ///Set the array size
    std::string tempY;
    std::getline(in, tempY);
    int yAmt = atoi( tempY.c_str() ); ///std::stoi(tempY);

    std::string tempX;
    std::getline(in, tempX);
    int xAmt = atoi( tempX.c_str() ); ///std::stoi(tempY);

    Node nodesArray[xAmt * yAmt];

    int xAxisCounter = -1;
    int yAxisCounter = 0;

    //std::cout << xAmt << ", " << yAmt << std::endl;

    ///Our Goal Node
    Node goalNode;

    char line;
    //while(in){
    for(int l = 0; l < yAmt; l++){

        //std::cout << line << std::endl;
        for(int i = 0; i < xAmt; i++){
            in.get(line);
            std::cout << line;
            if(line == 'X')
            {
                int temp = 0;
                while(nodesArray[temp].graphic != NULL)
                    temp++;
                ///Now our indexer is equal to a node that is equal to NULL
                nodesArray[temp].x = i;
                nodesArray[temp].y = l;
                nodesArray[temp].graphic = 'X';
                nodesArray[temp].full = true;

            }
            else if(line == ' '){
                int temp = 0;
                while(nodesArray[temp].graphic != NULL)
                    temp++;
                ///Now our indexer is equal to a node that is equal to NULL
                nodesArray[temp].x = i;
                nodesArray[temp].y = l;
                nodesArray[temp].graphic = ' ';
                nodesArray[temp].full = false;
            }
            else if(line == '$'){
                int temp = 0;
                while(nodesArray[temp].graphic != NULL)
                    temp++;
                ///Now our indexer is equal to a node that is equal to NULL
                nodesArray[temp].x = i;
                nodesArray[temp].y = l;
                nodesArray[temp].graphic = '$';
                nodesArray[temp].full = true;
                goalNode = nodesArray[temp];    ///We found our Goal Node to search to!
            }
        }
    }

    for(int i = 0; i < (xAmt * yAmt); i++)
        std::cout << nodesArray[i].graphic;


    in.close();
    //in.close(); ///Close the file

    return 0;
}
