#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cstdio>
#include <string>
#include <math.h>

class Node{
public:
    int x;
    int y;
    int cost;
    bool isBad = false;
};

///TODO: Create a Stack

int main()
{
    std::string fileName = "map.txt";    ///Map File

    std::ifstream in("map.txt", std::ios::in | std::ios::binary);
    if(!in){
        std::cerr << "Cannot open file" << std::endl;
        return 1;
    }

    ///Set the array size
    std::string tempY;
    std::getline(in, tempY);
    int yAmt = atoi( tempY.c_str() ); ///std::stoi(tempY);

    std::string tempX;
    std::getline(in, tempX);
    int xAmt = atoi( tempX.c_str() ); ///std::stoi(tempY);
    ///Map Array
    char mapArray[xAmt][yAmt];

    std::string line;

    for(int l = 0; l < yAmt; l++){
        std::getline(in, line);

        std::cout << line << std::endl;
        for(int i = 0; i < xAmt; i++){
            if(line[i] == 'X')
                mapArray[yAmt][xAmt] = line[i];
            else if(line[i] == ' ')
                myList.addNode(' ', i, l, false);
            else if(line[i] == '$')
                myList.addNode('$', i, l, false);
        }

    }

    return 0;
}
