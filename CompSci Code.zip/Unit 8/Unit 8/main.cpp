/*
Author: Patrick Malara
Date: April 28, 2016
Program: Unit 8 Assignment
*/

#include <iostream>
#include <fstream>
#include <string>

struct Node{
	int x;  ///X axis
	int y;  ///Y axis

	int g;  ///G Cost
	int h;  ///H Cost
	int f;  ///F Cost

	bool checked;
	bool used;

	Node* connectedNodes[4];
};

class LinkedList{

private:

	Node* head;
	Node* temp;

public:

	LinkedList(){
		head = NULL;
		temp = NULL;
	}
	/*
	~LinkedList(){
	if  ( head != NULL){

	Node* toDelete = head;
	Node* next = NULL;

	do{
	next = toDelete->next;
	delete toDelete;
	toDelete = next;
	}while ( toDelete != NULL);

	}

	}


	Node* getHead(){ return head; }

	void addNode(int x, int y){

	Node* n = new Node();
	n->x = x;
	n->y = y;
	n->next = NULL;

	if(head == NULL)    //If there is no List made
	head = n;   // set the head to the new Node created
	else if(head != NULL){  //If there is a List already made
	temp = head;
	while(temp->next != NULL)   //Get to the end of the list to add the new Node created
	temp = temp->next;
	temp->next = n;     // Add the new Node to the List
	}

	}
	*/

};

int main()
{

	std::ifstream in("map", std::ios::in | std::ios::binary);
	if (!in){
		std::cerr << "Cannot open file" << std::endl;
		return 1;
	}


	//ifstream infile("map.txt", ios::in);

	///Set the array size
	std::string tempY;
	std::getline(in, tempY);
	const int yAmt = std::stoi(tempY);
	std::string tempX;
	std::getline(in, tempX);
	const int xAmt = std::stoi(tempX);

	char nodesArray[xAmt][yAmt];

	LinkedList myList;
	int xAxisCounter = -1;
	int yAxisCounter = 0;

	///Loop through the file
	for (int y = 0; y < yAmt; y++)
	{
		for (int x = 0; x < xAmt; x++)
		{

			std::get(in, nodesArray[x][y]);
			std::cout << nodesArray[x][y];
		}

		std::cout << "\n";

	}


	/*========================================================================================

	///Loop through the map
	for(int y = 0; y < yAmt; y++)
	{
	for(int x = 0; x < xAmt; x++)
	{
	nodesArray[x][y] =
	}

	}

	///This should work for now
	while(temp != '*'){
	infile >> temp;

	if(temp == '/')
	{
	yAxisCounter++;
	xAxisCounter = 0;
	}
	else{
	xAxisCounter++;
	myList.addNode(xAxisCounter, yAxisCounter);
	}

	}

	Node* curr = new Node();
	curr = myList.getHead();

	cout << "Nodes" << endl;

	while(curr != NULL)
	{
	cout << curr->x << " " << curr->y<<endl;
	curr = curr->next;
	}

	delete curr;
	*/
	in.close();
	//in.close(); ///Close the file

	return 0;
}
