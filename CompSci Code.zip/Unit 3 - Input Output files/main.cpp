/*
    Author: Patrick Malara
    Date: April 18, 2016
    Program: Unit 3 Assignment
*/

#include <iostream>
#include <fstream>
#include <string.h>

using namespace std;    ///Wow, Patrick finnaly uses this. He deserves an A+ just for this.

int main()
{
    ///Variables
    string fileName = "test";
    int goodCounter = 0;

    ///Open the file
    ifstream infile;
    infile.open(fileName.c_str());

    ///Error Checking
    if(!infile.is_open())
    {
        ///Le problemo hereo
        cerr << "Unable to open file: " << fileName << endl;
        return 1;
    }

    int amount = 0;     ///Variable to the amount of names that will be in the texts files for each line
    infile >> amount;   ///Assign it to the first line of the text file

    ///Create two arrays to compare
    ///Their size is set by the first line in the text file which I cache in the amount integer
    string secondLine[amount];
    string thirdLine[amount];

    ///Set the first array to the words in the second line
    for(int i = 0; i < amount; i++){
        infile >> secondLine[i];     ///Set the element equal to the word
    }
    ///Set the second array to the words in the third line
    for(int j = 0; j < amount; j++){
        infile >> thirdLine[j];     ///Set the element equal to the word
    }

    ///Now that I have all the arrays set up, I loop through the first array to check
    ///if there are any similarites between it's elements and the third's line.
    for(int k = 0; k < amount; k++){
        ///Make sure that the value of this element is equal to itself
        if( secondLine[k] != thirdLine[k]){
            ///Loop through the third line for comparing
            for(int l = 0; l < amount; l++){
                ///Compare
                if(secondLine[k] == thirdLine[l]){
                    ///Final Check
                    if (secondLine[l] == thirdLine[k])
                        goodCounter++;      ///Goal!!!!!
                }
            }
        }
    }

    ///Output
    if(goodCounter == amount)
        cout << "good" << endl;
    else
        cout << "bad" << endl;

    infile.close(); ///Close the file

    return 0;
}
